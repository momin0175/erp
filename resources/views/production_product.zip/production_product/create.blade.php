{{ Form::open(array('url' => 'production', 'class'=>'needs-validation', 'novalidate')) }}
<div class="modal-body">

    <div class="row">

        {{-- Select Date Field --}}
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('select_date', __('Select Date'), ['class' => 'form-label']) }}<x-required></x-required>
                {{ Form::text('select_date', null, ['class' => 'form-control', 'id' => 'select_date', 'required' => 'required']) }}
            </div>
        </div>

        
        {{-- Product Selection --}}
        <div class="form-group col-md-6">
            <label for="product_id" class="form-label">Select Product<span style="color:red">*</span></label>
            <select name="product_id" id="product_id" class="form-control select" required>
                <option value="">Select Product</option>
                @foreach($productServices as $p_data)
                    <option value="{{ $p_data->id }}">{{ $p_data->name }}</option>
                @endforeach
            </select>
            <div class="text-xs">
                Please add product. <a href="{{route('productservice.index')}}"><b>Add Product</b></a>
            </div>
        </div>

        <div class="form-group col-md-6">
            <label for="shift" class="form-label">Select Shift <span style="color:red">*</span></label>
            <select name="shift" id="shift" class="form-control select" required>
                <option value="">Shift Shift</option>
                <option value="A">Shift A</option>
                <option value="B">Shift B</option>
            </select>
        </div>
        @if(\Auth::user()->companyTitle() == 'gio')
        {{-- Shift --}}
       

        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('thikness', __('Thikness'),['class'=>'form-label']) }}
                {{ Form::text('thikness', '', array('class' => 'form-control', 'placeholder' => __('Enter product thikness'))) }}
            </div>
        </div>
       

        {{-- GSM --}}
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('gsm', __('GSM'),['class'=>'form-label']) }}
                {{ Form::text('gsm', '', array('class' => 'form-control', 'placeholder' => __('Enter product GSM'))) }}
            </div>
        </div>

        {{-- Dia --}}
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('dia', __('Dia'),['class'=>'form-label']) }}
                {{ Form::text('dia', '', array('class' => 'form-control', 'placeholder' => __('Enter product dia'))) }}
            </div>
        </div>
        @endif
        
        @if(\Auth::user()->companyTitle() == 'jut')
        {{-- Size --}}
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('size', __('Size'),['class'=>'form-label']) }}
                {{ Form::text('size', '', array('class' => 'form-control', 'placeholder' => __('Enter product size'))) }}
            </div>
        </div>
        @endif

       {{-- Weight --}}
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('weight', __('Weight'),['class'=>'form-label']) }}
                {{ Form::text('weight', '', array('class' => 'form-control', 'placeholder' => __('Enter product weight'))) }}
            </div>
        </div>

        {{-- Porter Sort --}}
        @if(\Auth::user()->companyTitle() == 'jut')
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('porter_sort', __('Porter Sort'),['class'=>'form-label']) }}
                {{ Form::text('porter_sort', '', array('class' => 'form-control', 'placeholder' => __('Enter product porter sort'))) }}
            </div>
        </div>
        @endif

        {{-- Quantity --}}
        <div class="form-group col-md-6 quantity">
            {{ Form::label('quantity', __('Quantity'),['class'=>'form-label']) }}<x-required></x-required>
            {{ Form::number('quantity',null, array('class' => 'form-control', 'required'=>'required', 'placeholder' => __('Enter Quantity'))) }}
        </div>


    </div>
</div>
<div class="modal-footer">
    <input type="button" value="{{__('Cancel')}}" class="btn  btn-secondary" data-bs-dismiss="modal">
    <input type="submit" value="{{__('Create')}}" class="btn  btn-primary">
</div>
{{ Form::close() }}

<script>
    $(document).ready(function () {
        $('#select_date').datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true
        });
    });
</script>


